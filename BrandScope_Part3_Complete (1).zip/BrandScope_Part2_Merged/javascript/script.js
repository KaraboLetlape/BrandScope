/* =========================================================
   BRANDSCOPE — PART 3 INTERACTIVE JAVASCRIPT
   Search, accessible image gallery, enquiry validation/email
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    // PRODUCT SEARCH: filters the visible product cards as the user types.
    const searchInput = document.getElementById("productSearch");
    const clearSearch = document.getElementById("clearSearch");
    const searchStatus = document.getElementById("searchStatus");
    const productCards = Array.from(document.querySelectorAll("#productGrid .product-card"));

    function filterProducts() {
        if (!searchInput || productCards.length === 0) return;
        const query = searchInput.value.trim().toLowerCase();
        let visible = 0;
        productCards.forEach(card => {
            const matches = card.textContent.toLowerCase().includes(query);
            card.hidden = !matches;
            if (matches) visible++;
        });
        if (searchStatus) {
            searchStatus.textContent = query
                ? `${visible} product${visible === 1 ? "" : "s"} found for “${searchInput.value.trim()}”.`
                : "Showing all featured products.";
        }
    }
    if (searchInput) searchInput.addEventListener("input", filterProducts);
    if (clearSearch) clearSearch.addEventListener("click", () => {
        searchInput.value = "";
        filterProducts();
        searchInput.focus();
    });


    // HEADER SEARCH SHORTCUT
    const headerSearchButton = document.getElementById("headerSearchButton");
    if (headerSearchButton && searchInput) {
        headerSearchButton.addEventListener("click", () => {
            document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
            window.setTimeout(() => searchInput.focus(), 350);
        });
    }

    // ENQUIRY BAG: collect product selections and prepare a WhatsApp enquiry.
    const bag = document.getElementById("enquiryBag");
    const bagButton = document.getElementById("enquiryBagButton");
    const closeBagButton = document.getElementById("closeEnquiryBag");
    const bagItemsList = document.getElementById("enquiryBagItems");
    const bagCount = document.getElementById("enquiryBagCount");
    const bagTotal = document.getElementById("enquiryBagTotal");
    const sendBagWhatsApp = document.getElementById("sendBagWhatsApp");
    const selectedProducts = [];

    function renderEnquiryBag() {
        if (!bagItemsList) return;
        bagItemsList.innerHTML = "";
        if (selectedProducts.length === 0) {
            const empty = document.createElement("li");
            empty.textContent = "Your selected products will appear here.";
            bagItemsList.appendChild(empty);
        } else {
            selectedProducts.forEach((product, index) => {
                const item = document.createElement("li");
                item.textContent = `${product.name} — ${product.price} `;
                const remove = document.createElement("button");
                remove.type = "button";
                remove.className = "remove-enquiry-item";
                remove.textContent = "Remove";
                remove.setAttribute("aria-label", `Remove ${product.name}`);
                remove.addEventListener("click", () => {
                    selectedProducts.splice(index, 1);
                    renderEnquiryBag();
                });
                item.appendChild(remove);
                bagItemsList.appendChild(item);
            });
        }
        if (bagCount) bagCount.textContent = String(selectedProducts.length);
        if (bagTotal) bagTotal.textContent = `${selectedProducts.length} item${selectedProducts.length === 1 ? "" : "s"} selected`;
        if (sendBagWhatsApp) {
            const message = selectedProducts.length
                ? "Hi BrandScope, I would like to enquire about:\\n" + selectedProducts.map(p => `- ${p.name} (${p.price})`).join("\\n")
                : "Hi BrandScope, I would like to enquire about your collection.";
            sendBagWhatsApp.href = `https://wa.me/27794796968?text=${encodeURIComponent(message)}`;
            sendBagWhatsApp.setAttribute("aria-disabled", String(selectedProducts.length === 0));
        }
    }
    document.querySelectorAll(".add-enquiry-button").forEach(button => {
        button.addEventListener("click", () => {
            const name = button.dataset.product;
            const price = button.dataset.price;
            if (!selectedProducts.some(item => item.name === name)) {
                selectedProducts.push({ name, price });
                button.textContent = "ADDED TO ENQUIRY";
                button.setAttribute("aria-pressed", "true");
            } else {
                button.textContent = "ALREADY ADDED";
            }
            renderEnquiryBag();
        });
    });
    if (bagButton && bag) bagButton.addEventListener("click", () => {
        bag.classList.add("is-open");
        bag.setAttribute("aria-hidden", "false");
        renderEnquiryBag();
    });
    if (closeBagButton && bag) closeBagButton.addEventListener("click", () => {
        bag.classList.remove("is-open");
        bag.setAttribute("aria-hidden", "true");
        bagButton?.focus();
    });
    renderEnquiryBag();

    // GALLERY LIGHTBOX: works with product, category and detail-page images.
    const lightbox = document.getElementById("imageLightbox");
    const lightboxImage = document.getElementById("lightboxImage");
    const lightboxCaption = document.getElementById("lightboxCaption");
    const closeButton = document.getElementById("lightboxClose");
    const previousButton = document.getElementById("lightboxPrev");
    const nextButton = document.getElementById("lightboxNext");
    let galleryImages = [];
    let currentImageIndex = 0;
    let previousFocus = null;

    function collectGalleryImages() {
        return Array.from(document.querySelectorAll(
            ".category-image img, .product-image img, .product-details-image img"
        )).filter(img => img.getAttribute("src"));
    }
    function showGalleryImage(index) {
        if (!galleryImages.length || !lightbox) return;
        currentImageIndex = (index + galleryImages.length) % galleryImages.length;
        const selected = galleryImages[currentImageIndex];
        lightboxImage.src = selected.currentSrc || selected.src;
        lightboxImage.alt = selected.alt || "BrandScope product image";
        lightboxCaption.textContent = selected.alt || "BrandScope collection";
        if (previousButton) previousButton.hidden = galleryImages.length < 2;
        if (nextButton) nextButton.hidden = galleryImages.length < 2;
    }
    function openLightbox(image) {
        if (!lightbox || !lightboxImage) return;
        galleryImages = collectGalleryImages();
        currentImageIndex = galleryImages.indexOf(image);
        if (currentImageIndex < 0) currentImageIndex = 0;
        previousFocus = document.activeElement;
        showGalleryImage(currentImageIndex);
        lightbox.classList.add("is-open");
        lightbox.setAttribute("aria-hidden", "false");
        document.body.classList.add("lightbox-active");
        if (closeButton) closeButton.focus();
    }
    function closeLightbox() {
        if (!lightbox) return;
        lightbox.classList.remove("is-open");
        lightbox.setAttribute("aria-hidden", "true");
        document.body.classList.remove("lightbox-active");
        if (lightboxImage) lightboxImage.src = "";
        if (previousFocus && typeof previousFocus.focus === "function") previousFocus.focus();
    }
    document.addEventListener("click", event => {
        const image = event.target.closest(".category-image img, .product-image img, .product-details-image img");
        if (image) openLightbox(image);
    });
    if (closeButton) closeButton.addEventListener("click", closeLightbox);
    if (previousButton) previousButton.addEventListener("click", () => showGalleryImage(currentImageIndex - 1));
    if (nextButton) nextButton.addEventListener("click", () => showGalleryImage(currentImageIndex + 1));
    if (lightbox) lightbox.addEventListener("click", event => {
        if (event.target === lightbox) closeLightbox();
    });
    document.addEventListener("keydown", event => {
        if (!lightbox || !lightbox.classList.contains("is-open")) return;
        if (event.key === "Escape") closeLightbox();
        if (event.key === "ArrowLeft" && galleryImages.length > 1) showGalleryImage(currentImageIndex - 1);
        if (event.key === "ArrowRight" && galleryImages.length > 1) showGalleryImage(currentImageIndex + 1);
    });

    // ENQUIRY FORM: validates every field and prepares a real email for the visitor.
    const form = document.getElementById("contactForm");
    if (!form) return;

    const feedback = document.getElementById("formFeedback");
    const fieldRules = [
        { id: "name", error: "nameError", message: "Please enter your name (at least 2 characters).",
          valid: value => value.trim().length >= 2 },
        { id: "email", error: "emailError", message: "Please enter a valid email address.",
          valid: value => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim()) },
        { id: "phone", error: "phoneError", message: "Please enter a valid phone number or leave it blank.",
          valid: value => value.trim() === "" || /^[+0-9() -]{7,20}$/.test(value.trim()) },
        { id: "subject", error: "subjectError", message: "Please select an enquiry type.",
          valid: value => value.trim() !== "" },
        { id: "message", error: "messageError", message: "Please enter a message of at least 10 characters.",
          valid: value => value.trim().length >= 10 && value.trim().length <= 1000 }
    ];

    function validateField(rule) {
        const field = document.getElementById(rule.id);
        const error = document.getElementById(rule.error);
        const valid = rule.valid(field.value);
        field.setAttribute("aria-invalid", String(!valid));
        if (error) error.textContent = valid ? "" : rule.message;
        return valid;
    }
    fieldRules.forEach(rule => {
        const field = document.getElementById(rule.id);
        if (field) {
            field.addEventListener("blur", () => validateField(rule));
            field.addEventListener("input", () => {
                if (field.getAttribute("aria-invalid") === "true") validateField(rule);
            });
            field.addEventListener("change", () => validateField(rule));
        }
    });

    form.addEventListener("submit", event => {
        event.preventDefault();
        const valid = fieldRules.map(validateField).every(Boolean);
        if (!valid) {
            feedback.textContent = "Please correct the highlighted fields before sending your enquiry.";
            feedback.className = "form-feedback error";
            const firstInvalid = form.querySelector('[aria-invalid="true"]');
            if (firstInvalid) firstInvalid.focus();
            return;
        }

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const phone = document.getElementById("phone").value.trim() || "Not provided";
        const subject = document.getElementById("subject").value;
        const message = document.getElementById("message").value.trim();
        const emailSubject = `BrandScope website enquiry: ${subject}`;
        const body = [
            `Name: ${name}`,
            `Email: ${email}`,
            `Phone: ${phone}`,
            `Enquiry type: ${subject}`,
            "",
            "Message:",
            message
        ].join("\n");

        feedback.textContent = "Your email application should open with the enquiry prepared. Review it and press Send to contact BrandScope.";
        feedback.className = "form-feedback success";
        const mailto = `mailto:brandscope.za@gmail.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(body)}`;
        window.location.href = mailto;
    });
});
